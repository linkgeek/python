﻿namespace ESRI_01
{
    partial class AttributesContextMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.闪烁该要素ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.缩放缩放到该要素ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.平移到该要素ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.缩放到当前图层ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.缩放到所有选择要素ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.清楚所有选择要素ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除所有选择要素ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(501, 287);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseDown);
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 287);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(501, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel2.Text = "toolStripStatusLabel2";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.闪烁该要素ToolStripMenuItem,
            this.缩放缩放到该要素ToolStripMenuItem,
            this.平移到该要素ToolStripMenuItem,
            this.toolStripMenuItem1,
            this.缩放到当前图层ToolStripMenuItem,
            this.toolStripMenuItem2,
            this.缩放到所有选择要素ToolStripMenuItem,
            this.清楚所有选择要素ToolStripMenuItem,
            this.删除所有选择要素ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(183, 192);
            // 
            // 闪烁该要素ToolStripMenuItem
            // 
            this.闪烁该要素ToolStripMenuItem.Name = "闪烁该要素ToolStripMenuItem";
            this.闪烁该要素ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.闪烁该要素ToolStripMenuItem.Text = "闪烁该要素";
            this.闪烁该要素ToolStripMenuItem.Click += new System.EventHandler(this.闪烁该要素ToolStripMenuItem_Click);
            // 
            // 缩放缩放到该要素ToolStripMenuItem
            // 
            this.缩放缩放到该要素ToolStripMenuItem.Name = "缩放缩放到该要素ToolStripMenuItem";
            this.缩放缩放到该要素ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.缩放缩放到该要素ToolStripMenuItem.Text = "缩放缩放到该要素";
            this.缩放缩放到该要素ToolStripMenuItem.Click += new System.EventHandler(this.缩放缩放到该要素ToolStripMenuItem_Click);
            // 
            // 平移到该要素ToolStripMenuItem
            // 
            this.平移到该要素ToolStripMenuItem.Name = "平移到该要素ToolStripMenuItem";
            this.平移到该要素ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.平移到该要素ToolStripMenuItem.Text = "平移到该要素";
            this.平移到该要素ToolStripMenuItem.Click += new System.EventHandler(this.平移到该要素ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(179, 6);
            // 
            // 缩放到当前图层ToolStripMenuItem
            // 
            this.缩放到当前图层ToolStripMenuItem.Name = "缩放到当前图层ToolStripMenuItem";
            this.缩放到当前图层ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.缩放到当前图层ToolStripMenuItem.Text = "缩放到当前图层";
            this.缩放到当前图层ToolStripMenuItem.Click += new System.EventHandler(this.缩放到当前图层ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(179, 6);
            // 
            // 缩放到所有选择要素ToolStripMenuItem
            // 
            this.缩放到所有选择要素ToolStripMenuItem.Name = "缩放到所有选择要素ToolStripMenuItem";
            this.缩放到所有选择要素ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.缩放到所有选择要素ToolStripMenuItem.Text = "缩放到所有选择要素";
            this.缩放到所有选择要素ToolStripMenuItem.Click += new System.EventHandler(this.缩放到所有选择要素ToolStripMenuItem_Click);
            // 
            // 清楚所有选择要素ToolStripMenuItem
            // 
            this.清楚所有选择要素ToolStripMenuItem.Name = "清楚所有选择要素ToolStripMenuItem";
            this.清楚所有选择要素ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.清楚所有选择要素ToolStripMenuItem.Text = "清除所有选择要素";
            this.清楚所有选择要素ToolStripMenuItem.Click += new System.EventHandler(this.清楚所有选择要素ToolStripMenuItem_Click);
            // 
            // 删除所有选择要素ToolStripMenuItem
            // 
            this.删除所有选择要素ToolStripMenuItem.Name = "删除所有选择要素ToolStripMenuItem";
            this.删除所有选择要素ToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.删除所有选择要素ToolStripMenuItem.Text = "删除所有选择要素";
            this.删除所有选择要素ToolStripMenuItem.Click += new System.EventHandler(this.删除所有选择要素ToolStripMenuItem_Click);
            // 
            // AttributesContextMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 309);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.statusStrip1);
            this.Name = "AttributesContextMenu";
            this.Text = "AttributesContextMenu";
            this.Load += new System.EventHandler(this.AttributesContextMenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 闪烁该要素ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 缩放缩放到该要素ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 平移到该要素ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 缩放到当前图层ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem 缩放到所有选择要素ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 清楚所有选择要素ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除所有选择要素ToolStripMenuItem;
    }
}