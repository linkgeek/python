﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.Display;

namespace ESRI_01
{
    public partial class AttributesContextMenu : Form
    {
        IMapControl4 pMapControl;
        IMap pMap;
        IFeatureLayer currentLayer;
        IActiveView pActiveView;
        string strOBJECTEDID = null;
        int currentRow = 0;

        public AttributesContextMenu(IMapControl4 mapControl,IFeatureLayer featurelayer)
        {
            InitializeComponent();
            pMapControl = mapControl;
            pMap = pMapControl.Map;
            currentLayer = featurelayer;
            pActiveView = pMapControl.ActiveView;
        }

        private void AttributesContextMenu_Load(object sender, EventArgs e)
        {
            FindOID();
            LoadAttributes();
        }

        private void FindOID()
        {
            IFeatureClass pFeatureClass = currentLayer.FeatureClass;
            IFields pFields = pFeatureClass.Fields;
            for (int i = 0; i < pFields.FieldCount;i++ )
            {
                if (pFields.get_Field(i).Type == esriFieldType.esriFieldTypeOID)
                {
                    strOBJECTEDID = pFields.get_Field(i).Name;
                    break;
                }
            }
        }

        private void LoadAttributes()
        {
            IFeatureClass pFeatureClass = currentLayer.FeatureClass;
            IFields pFields = pFeatureClass.Fields;
            IFeatureCursor pFeatureCursor = pFeatureClass.Search(null, false);
            IFeature pFeature = pFeatureCursor.NextFeature();
            DataTable pTable = new DataTable();
            for (int i = 0; i < pFields.FieldCount;i++ )
            {
                pTable.Columns.Add(pFields.get_Field(i).Name);
            }
            while (pFeature != null)
            {
                DataRow row = pTable.NewRow();
                for (int i = 0; i < pFields.FieldCount;i++ )
                {
                    row[i] = pFeature.get_Value(i);
                }
                pTable.Rows.Add(row);
                pFeature = pFeatureCursor.NextFeature();
            }
            dataGridView1.DataSource = pTable;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.Columns[3].DisplayIndex = 5;
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                pMap.ClearSelection();
                pActiveView.Refresh();

                DataGridViewSelectedRowCollection selectRows = dataGridView1.SelectedRows;
	            List<string> OIDList = new List<string>();
	            string strOID = null;
	            for (int i = 0; i < selectRows.Count;i++ )
	            {
	                strOID = selectRows[i].Cells[strOBJECTEDID].Value.ToString();
	                OIDList.Add(strOID);
	            }
	            string[] OIDArray = OIDList.ToArray();
	            IFeatureClass pFeatureClass = currentLayer.FeatureClass;
	            IFeature pFeature = null;
	            for (int i = 0; i < OIDArray.Length;i++ )
	            {
	                pFeature = pFeatureClass.GetFeature(Convert.ToInt32(OIDArray[i]));
	                pMap.SelectFeature(currentLayer, pFeature);
	            }
	            pActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeoSelection, null, null);
                toolStripStatusLabel1.Text = "所又要素个数：" + pFeatureClass.FeatureCount(null).ToString();
                toolStripStatusLabel2.Text = "所选要素个数：" + OIDArray.Length;
            }
            catch (System.Exception ex)
            {
            }
        }

        private void dataGridView1_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if(e.Button == MouseButtons.Right)
            {
                currentRow = e.RowIndex;
                contextMenuStrip1.Show(System.Windows.Forms.Cursor.Position);
            }
        }

        private void 闪烁该要素ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IFeature pFeature = GetFeature();
            IGeometry pGeo = pFeature.Shape;

            ISimpleMarkerSymbol pSimMarkerSym = new SimpleMarkerSymbol();
            pSimMarkerSym.Color = GetColor(0,255,0);
            pSimMarkerSym.Style = esriSimpleMarkerStyle.esriSMSCircle;

            ISimpleLineSymbol pSimLineSym = new SimpleLineSymbol();
            pSimLineSym.Color = GetColor(255,128,0);
            pSimLineSym.Width = 2;

            ISimpleFillSymbol pSimFillSym = new SimpleFillSymbol();
            pSimFillSym.Outline = pSimLineSym;
            pSimFillSym.Color = GetColor(0,255,0);

            object symbol = null;
            if (pGeo.GeometryType == esriGeometryType.esriGeometryPoint)
            {
                symbol = pSimMarkerSym;
            }
            else if (pGeo.GeometryType == esriGeometryType.esriGeometryPolyline)
            {
                symbol = pSimLineSym;
            }
            else if (pGeo.GeometryType == esriGeometryType.esriGeometryPolygon)
            {
                symbol = pSimFillSym;
            }
            pMapControl.FlashShape(pGeo, 3, 300, symbol);
        }

        private void 缩放缩放到该要素ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IEnvelope featureEnv = GetFeature().Shape.Envelope;
            IPoint centrePoint = new PointClass();
            centrePoint.X = (featureEnv.LowerLeft.X + featureEnv.UpperRight.X) / 2;
            centrePoint.Y = (featureEnv.LowerLeft.Y + featureEnv.UpperRight.Y) / 2;
            IEnvelope pEnv = pMapControl.Extent;
            pEnv.Expand(0.5, 0.5, true);
            pMapControl.Extent = pEnv;
            pMapControl.CenterAt(centrePoint);
            pActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);
        }

        private void 平移到该要素ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pMapControl.Extent = GetFeature().Shape.Envelope;
            pActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);
        }

        private IFeature GetFeature()
        {
            IFeatureClass pFeatureClass = currentLayer.FeatureClass;
            string strOID = dataGridView1.Rows[currentRow].Cells[strOBJECTEDID].Value.ToString();
            IFeature pFeature = pFeatureClass.GetFeature(Convert.ToInt32(strOID));
            return pFeature;
        }

        private IRgbColor GetColor(int r,int g,int b)
        {
            IRgbColor pColor = new RgbColor();
            pColor.Red = r;
            pColor.Green = g;
            pColor.Blue = b;
            return pColor;
        }

        private void 缩放到当前图层ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pMapControl.Extent = ((IGeoDataset)currentLayer).Extent;
            pActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);
        }

        private void 缩放到所有选择要素ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IEnvelope AllEnvelope = null;
            IFeatureClass pFeatureClass = currentLayer.FeatureClass;
            IFeatureSelection pFeatureSelection = currentLayer as IFeatureSelection;
            ISelectionSet pSelectionSet = pFeatureSelection.SelectionSet;
            IEnumIDs pEnumIDs = pSelectionSet.IDs;
            int ID = pEnumIDs.Next();
            if (ID == -1) return;
            IFeature pFeature = pFeatureClass.GetFeature(ID);
            AllEnvelope = pFeature.Shape.Envelope;
            ID = pEnumIDs.Next();
            while (ID != -1)
            {
                pFeature = pFeatureClass.GetFeature(ID);
                AllEnvelope.Union(pFeature.Shape.Envelope);
                ID = pEnumIDs.Next();
            }
            pMapControl.Extent = AllEnvelope;
            pActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);
        }

        private void 清楚所有选择要素ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            pMap.ClearSelection();
            pActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);
        }

        private void 删除所有选择要素ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //删除要素的时候，必须要先删除后面的，因为，没删一个要素的时候，OID就会重新分配一次，而从后往前删，使得前面的部分在重新
            //分配之后不发生变化，Add方法，将最后面加入的要素放在了最上面，所以正常遍历的时候，是从下面往上面遍历的！
            DataGridViewSelectedRowCollection selectRows = dataGridView1.SelectedRows;  //重新将选择的行排序
            List<string> OIDList = new List<string>();
            string strOID = string.Empty;
            for (int i = 0; i < selectRows.Count; i++)
            {
                DataGridViewRow row = selectRows[i];
                strOID = row.Cells[strOBJECTEDID].Value.ToString();   //将重新排序的OID值提取出来
                OIDList.Add(strOID);
            }
            string[] OIDArray = OIDList.ToArray();
            IFeatureClass pFeatureClass = currentLayer.FeatureClass;
            IFeature pFeature = null;
            for (int i = 0; i < OIDArray.Length; i++)
            {
                pFeature = pFeatureClass.GetFeature(Convert.ToInt32(OIDArray[i]));
                if (MessageBox.Show("确定删除" + pFeature.get_Value(3).ToString() + "吗(⊙_⊙?)", "Warning", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    pFeature.Delete();
                    pActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);
                }
            }

            dataGridView1.DataSource = null;
            LoadAttributes();
        }
    }
}
