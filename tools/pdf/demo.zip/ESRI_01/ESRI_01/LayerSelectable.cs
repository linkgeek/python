﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.SystemUI;
using ESRI.ArcGIS.Carto;

namespace ESRI_01
{
    /// <summary>
    /// Summary description for LayerSelectable.
    /// </summary>
    [Guid("7d98a029-ece5-4f73-9b0f-6caa3125c3e2")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("ESRI_01.LayerSelectable")]
    public sealed class LayerSelectable : BaseCommand, ICommandSubType
    {
        #region COM Registration Function(s)
        [ComRegisterFunction()]
        [ComVisible(false)]
        static void RegisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryRegistration(registerType);

            //
            // TODO: Add any COM registration code here
            //
        }

        [ComUnregisterFunction()]
        [ComVisible(false)]
        static void UnregisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryUnregistration(registerType);

            //
            // TODO: Add any COM unregistration code here
            //
        }

        #region ArcGIS Component Category Registrar generated code
        /// <summary>
        /// Required method for ArcGIS Component Category registration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryRegistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Register(regKey);

        }
        /// <summary>
        /// Required method for ArcGIS Component Category unregistration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryUnregistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Unregister(regKey);

        }

        #endregion
        #endregion

        private IMapControl4 m_mapControl;
        long m_subType;

        public LayerSelectable()
        {
        }

        #region Overriden Class Methods

        /// <summary>
        /// Occurs when this command is created
        /// </summary>
        /// <param name="hook">Instance of the application</param>
        public override void OnCreate(object hook)
        {
            if (hook is IMapControl4)
            {
                m_mapControl = hook as IMapControl4;
            }
        }

        /// <summary>
        /// Occurs when this command is clicked
        /// </summary>
        public override void OnClick()
        {
            ILayer layer = m_mapControl.CustomProperty as ILayer;
            IFeatureLayer featureLayer = layer as IFeatureLayer;
            if (m_subType == 1)
            {
                featureLayer.Selectable = true;
            }
            else
            {
                featureLayer.Selectable = false;
            }
        }

        public override bool Enabled
        {
            get
            {
                ILayer layer = m_mapControl.CustomProperty as ILayer;
                IFeatureLayer featureLayer = layer as IFeatureLayer;

                if (m_subType == 1)
                {
                    return !featureLayer.Selectable;
                }
                else
                {
                    return featureLayer.Selectable;
                }
            }
        }

        public override string Caption
        {
            get
            {
                if (m_subType == 1)
                {
                    return "可选择要素";
                }
                else 
                {
                    return "不可选择要素";
                }
            }
        }

        #endregion

        #region ICommandSubType 成员

        public int GetCount()
        {
            return 2;
        }

        public void SetSubType(int SubType)
        {
            m_subType = SubType;
        }

        #endregion
    }
}
