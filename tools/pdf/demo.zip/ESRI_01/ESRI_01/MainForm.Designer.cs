﻿namespace lesson1._1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.axLicenseControl1 = new ESRI.ArcGIS.Controls.AxLicenseControl();
            this.axToolbarControl1 = new ESRI.ArcGIS.Controls.AxToolbarControl();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuNewDoc = new System.Windows.Forms.ToolStripMenuItem();
            this.menuOpenDoc = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSaveDoc = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.AddData = new System.Windows.Forms.ToolStripMenuItem();
            this.menuExitApp = new System.Windows.Forms.ToolStripMenuItem();
            this.mapControl控件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.载入文档ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.绘制图形元素ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.线转元素ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.矩形元素ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.圆形元素ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.多边形元素ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.改变地图显示范围拉框ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.数据选择拉多边形ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pageLayoutControl控件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.载入文档ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.绘制元素SamplesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.borderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backgroundToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shadowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mapGridToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pageLayoutControl与ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tOCControl控件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.相应功能查看帮助文档ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolbarControl控件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.驻留命令sampleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新建地图文档ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolbarMenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolbarPaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.axTOCControl1 = new ESRI.ArcGIS.Controls.AxTOCControl();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.axMapControl1 = new ESRI.ArcGIS.Controls.AxMapControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.axPageLayoutControl1 = new ESRI.ArcGIS.Controls.AxPageLayoutControl();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.axLicenseControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axToolbarControl1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axTOCControl1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axMapControl1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axPageLayoutControl1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // axLicenseControl1
            // 
            this.axLicenseControl1.Enabled = true;
            this.axLicenseControl1.Location = new System.Drawing.Point(787, 449);
            this.axLicenseControl1.Name = "axLicenseControl1";
            this.axLicenseControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axLicenseControl1.OcxState")));
            this.axLicenseControl1.Size = new System.Drawing.Size(32, 32);
            this.axLicenseControl1.TabIndex = 2;
            // 
            // axToolbarControl1
            // 
            this.axToolbarControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.axToolbarControl1.Location = new System.Drawing.Point(0, 24);
            this.axToolbarControl1.Name = "axToolbarControl1";
            this.axToolbarControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axToolbarControl1.OcxState")));
            this.axToolbarControl1.Size = new System.Drawing.Size(793, 28);
            this.axToolbarControl1.TabIndex = 3;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.文件ToolStripMenuItem,
            this.mapControl控件ToolStripMenuItem,
            this.pageLayoutControl控件ToolStripMenuItem,
            this.tOCControl控件ToolStripMenuItem,
            this.toolbarControl控件ToolStripMenuItem,
            this.帮助ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(793, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 文件ToolStripMenuItem
            // 
            this.文件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuNewDoc,
            this.menuOpenDoc,
            this.menuSaveDoc,
            this.menuSaveAs,
            this.toolStripSeparator1,
            this.AddData,
            this.menuExitApp});
            this.文件ToolStripMenuItem.Name = "文件ToolStripMenuItem";
            this.文件ToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.文件ToolStripMenuItem.Text = "文件";
            // 
            // menuNewDoc
            // 
            this.menuNewDoc.Image = global::ESRI_01.Properties.Resources.New;
            this.menuNewDoc.Name = "menuNewDoc";
            this.menuNewDoc.Size = new System.Drawing.Size(122, 22);
            this.menuNewDoc.Text = "新建文件";
            this.menuNewDoc.Click += new System.EventHandler(this.新建文件ToolStripMenuItem_Click);
            // 
            // menuOpenDoc
            // 
            this.menuOpenDoc.Image = global::ESRI_01.Properties.Resources.Open;
            this.menuOpenDoc.Name = "menuOpenDoc";
            this.menuOpenDoc.Size = new System.Drawing.Size(122, 22);
            this.menuOpenDoc.Text = "打开文件";
            this.menuOpenDoc.Click += new System.EventHandler(this.打开文件ToolStripMenuItem_Click);
            // 
            // menuSaveDoc
            // 
            this.menuSaveDoc.Image = global::ESRI_01.Properties.Resources.Save;
            this.menuSaveDoc.Name = "menuSaveDoc";
            this.menuSaveDoc.Size = new System.Drawing.Size(122, 22);
            this.menuSaveDoc.Text = "保存文件";
            this.menuSaveDoc.Click += new System.EventHandler(this.保存文件ToolStripMenuItem_Click);
            // 
            // menuSaveAs
            // 
            this.menuSaveAs.Name = "menuSaveAs";
            this.menuSaveAs.Size = new System.Drawing.Size(122, 22);
            this.menuSaveAs.Text = "另存为 ...";
            this.menuSaveAs.Click += new System.EventHandler(this.另存为ToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(119, 6);
            // 
            // AddData
            // 
            this.AddData.Image = global::ESRI_01.Properties.Resources.AddData;
            this.AddData.Name = "AddData";
            this.AddData.Size = new System.Drawing.Size(122, 22);
            this.AddData.Text = "添加数据";
            this.AddData.Click += new System.EventHandler(this.AddData_Click);
            // 
            // menuExitApp
            // 
            this.menuExitApp.Name = "menuExitApp";
            this.menuExitApp.Size = new System.Drawing.Size(122, 22);
            this.menuExitApp.Text = "退出";
            this.menuExitApp.Click += new System.EventHandler(this.menuExitApp_Click);
            // 
            // mapControl控件ToolStripMenuItem
            // 
            this.mapControl控件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.载入文档ToolStripMenuItem,
            this.toolStripMenuItem1,
            this.绘制图形元素ToolStripMenuItem,
            this.改变地图显示范围拉框ToolStripMenuItem,
            this.toolStripMenuItem2,
            this.数据选择拉多边形ToolStripMenuItem});
            this.mapControl控件ToolStripMenuItem.Name = "mapControl控件ToolStripMenuItem";
            this.mapControl控件ToolStripMenuItem.Size = new System.Drawing.Size(110, 20);
            this.mapControl控件ToolStripMenuItem.Text = "MapControl 控件";
            // 
            // 载入文档ToolStripMenuItem
            // 
            this.载入文档ToolStripMenuItem.Name = "载入文档ToolStripMenuItem";
            this.载入文档ToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.载入文档ToolStripMenuItem.Text = "载入文档";
            this.载入文档ToolStripMenuItem.Click += new System.EventHandler(this.载入文档ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(215, 6);
            // 
            // 绘制图形元素ToolStripMenuItem
            // 
            this.绘制图形元素ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.线转元素ToolStripMenuItem,
            this.矩形元素ToolStripMenuItem,
            this.圆形元素ToolStripMenuItem,
            this.多边形元素ToolStripMenuItem});
            this.绘制图形元素ToolStripMenuItem.Name = "绘制图形元素ToolStripMenuItem";
            this.绘制图形元素ToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.绘制图形元素ToolStripMenuItem.Text = "绘制图形元素";
            // 
            // 线转元素ToolStripMenuItem
            // 
            this.线转元素ToolStripMenuItem.Name = "线转元素ToolStripMenuItem";
            this.线转元素ToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.线转元素ToolStripMenuItem.Text = "线状元素";
            this.线转元素ToolStripMenuItem.Click += new System.EventHandler(this.线转元素ToolStripMenuItem_Click);
            // 
            // 矩形元素ToolStripMenuItem
            // 
            this.矩形元素ToolStripMenuItem.Name = "矩形元素ToolStripMenuItem";
            this.矩形元素ToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.矩形元素ToolStripMenuItem.Text = "矩形元素";
            this.矩形元素ToolStripMenuItem.Click += new System.EventHandler(this.矩形元素ToolStripMenuItem_Click);
            // 
            // 圆形元素ToolStripMenuItem
            // 
            this.圆形元素ToolStripMenuItem.Name = "圆形元素ToolStripMenuItem";
            this.圆形元素ToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.圆形元素ToolStripMenuItem.Text = "圆形元素";
            this.圆形元素ToolStripMenuItem.Click += new System.EventHandler(this.圆形元素ToolStripMenuItem_Click);
            // 
            // 多边形元素ToolStripMenuItem
            // 
            this.多边形元素ToolStripMenuItem.Name = "多边形元素ToolStripMenuItem";
            this.多边形元素ToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.多边形元素ToolStripMenuItem.Text = "多边形元素";
            this.多边形元素ToolStripMenuItem.Click += new System.EventHandler(this.多边形元素ToolStripMenuItem_Click);
            // 
            // 改变地图显示范围拉框ToolStripMenuItem
            // 
            this.改变地图显示范围拉框ToolStripMenuItem.Name = "改变地图显示范围拉框ToolStripMenuItem";
            this.改变地图显示范围拉框ToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.改变地图显示范围拉框ToolStripMenuItem.Text = "改变地图显示范围（拉框）";
            this.改变地图显示范围拉框ToolStripMenuItem.Click += new System.EventHandler(this.改变地图显示范围拉框ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(215, 6);
            // 
            // 数据选择拉多边形ToolStripMenuItem
            // 
            this.数据选择拉多边形ToolStripMenuItem.Name = "数据选择拉多边形ToolStripMenuItem";
            this.数据选择拉多边形ToolStripMenuItem.Size = new System.Drawing.Size(218, 22);
            this.数据选择拉多边形ToolStripMenuItem.Text = "数据选择（拉多边形）";
            this.数据选择拉多边形ToolStripMenuItem.Click += new System.EventHandler(this.数据选择拉多边形ToolStripMenuItem_Click);
            // 
            // pageLayoutControl控件ToolStripMenuItem
            // 
            this.pageLayoutControl控件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.载入文档ToolStripMenuItem1,
            this.绘制元素SamplesToolStripMenuItem,
            this.pageLayoutControl与ToolStripMenuItem});
            this.pageLayoutControl控件ToolStripMenuItem.Name = "pageLayoutControl控件ToolStripMenuItem";
            this.pageLayoutControl控件ToolStripMenuItem.Size = new System.Drawing.Size(148, 20);
            this.pageLayoutControl控件ToolStripMenuItem.Text = "PageLayoutControl 控件";
            // 
            // 载入文档ToolStripMenuItem1
            // 
            this.载入文档ToolStripMenuItem1.Name = "载入文档ToolStripMenuItem1";
            this.载入文档ToolStripMenuItem1.Size = new System.Drawing.Size(285, 22);
            this.载入文档ToolStripMenuItem1.Text = "载入文档";
            this.载入文档ToolStripMenuItem1.Click += new System.EventHandler(this.载入文档ToolStripMenuItem1_Click);
            // 
            // 绘制元素SamplesToolStripMenuItem
            // 
            this.绘制元素SamplesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.borderToolStripMenuItem,
            this.backgroundToolStripMenuItem,
            this.shadowToolStripMenuItem,
            this.mapGridToolStripMenuItem});
            this.绘制元素SamplesToolStripMenuItem.Name = "绘制元素SamplesToolStripMenuItem";
            this.绘制元素SamplesToolStripMenuItem.Size = new System.Drawing.Size(285, 22);
            this.绘制元素SamplesToolStripMenuItem.Text = "绘制元素（Samples）";
            // 
            // borderToolStripMenuItem
            // 
            this.borderToolStripMenuItem.Name = "borderToolStripMenuItem";
            this.borderToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.borderToolStripMenuItem.Text = "Border";
            this.borderToolStripMenuItem.Click += new System.EventHandler(this.borderToolStripMenuItem_Click);
            // 
            // backgroundToolStripMenuItem
            // 
            this.backgroundToolStripMenuItem.Name = "backgroundToolStripMenuItem";
            this.backgroundToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.backgroundToolStripMenuItem.Text = "Background";
            this.backgroundToolStripMenuItem.Click += new System.EventHandler(this.backgroundToolStripMenuItem_Click);
            // 
            // shadowToolStripMenuItem
            // 
            this.shadowToolStripMenuItem.Name = "shadowToolStripMenuItem";
            this.shadowToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.shadowToolStripMenuItem.Text = "Shadow";
            this.shadowToolStripMenuItem.Click += new System.EventHandler(this.shadowToolStripMenuItem_Click);
            // 
            // mapGridToolStripMenuItem
            // 
            this.mapGridToolStripMenuItem.Name = "mapGridToolStripMenuItem";
            this.mapGridToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.mapGridToolStripMenuItem.Text = "MapGrid";
            this.mapGridToolStripMenuItem.Click += new System.EventHandler(this.mapGridToolStripMenuItem_Click);
            // 
            // pageLayoutControl与ToolStripMenuItem
            // 
            this.pageLayoutControl与ToolStripMenuItem.Name = "pageLayoutControl与ToolStripMenuItem";
            this.pageLayoutControl与ToolStripMenuItem.Size = new System.Drawing.Size(285, 22);
            this.pageLayoutControl与ToolStripMenuItem.Text = "PageLayoutControl 与 MapControl 联动";
            // 
            // tOCControl控件ToolStripMenuItem
            // 
            this.tOCControl控件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.相应功能查看帮助文档ToolStripMenuItem});
            this.tOCControl控件ToolStripMenuItem.Name = "tOCControl控件ToolStripMenuItem";
            this.tOCControl控件ToolStripMenuItem.Size = new System.Drawing.Size(110, 20);
            this.tOCControl控件ToolStripMenuItem.Text = "TOCControl 控件";
            // 
            // 相应功能查看帮助文档ToolStripMenuItem
            // 
            this.相应功能查看帮助文档ToolStripMenuItem.Name = "相应功能查看帮助文档ToolStripMenuItem";
            this.相应功能查看帮助文档ToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.相应功能查看帮助文档ToolStripMenuItem.Text = "相应功能查看帮助文档";
            // 
            // toolbarControl控件ToolStripMenuItem
            // 
            this.toolbarControl控件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.驻留命令sampleToolStripMenuItem,
            this.toolbarMenuToolStripMenuItem,
            this.toolbarPaletteToolStripMenuItem});
            this.toolbarControl控件ToolStripMenuItem.Name = "toolbarControl控件ToolStripMenuItem";
            this.toolbarControl控件ToolStripMenuItem.Size = new System.Drawing.Size(127, 20);
            this.toolbarControl控件ToolStripMenuItem.Text = "ToolbarControl 控件";
            // 
            // 驻留命令sampleToolStripMenuItem
            // 
            this.驻留命令sampleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新建地图文档ToolStripMenuItem});
            this.驻留命令sampleToolStripMenuItem.Name = "驻留命令sampleToolStripMenuItem";
            this.驻留命令sampleToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.驻留命令sampleToolStripMenuItem.Text = "驻留命令(sample)";
            // 
            // 新建地图文档ToolStripMenuItem
            // 
            this.新建地图文档ToolStripMenuItem.Name = "新建地图文档ToolStripMenuItem";
            this.新建地图文档ToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.新建地图文档ToolStripMenuItem.Text = "新建地图文档";
            this.新建地图文档ToolStripMenuItem.Click += new System.EventHandler(this.新建地图文档ToolStripMenuItem_Click);
            // 
            // toolbarMenuToolStripMenuItem
            // 
            this.toolbarMenuToolStripMenuItem.Name = "toolbarMenuToolStripMenuItem";
            this.toolbarMenuToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.toolbarMenuToolStripMenuItem.Text = "ToolbarMenu";
            this.toolbarMenuToolStripMenuItem.Click += new System.EventHandler(this.toolbarMenuToolStripMenuItem_Click);
            // 
            // toolbarPaletteToolStripMenuItem
            // 
            this.toolbarPaletteToolStripMenuItem.Name = "toolbarPaletteToolStripMenuItem";
            this.toolbarPaletteToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.toolbarPaletteToolStripMenuItem.Text = "ToolbarPalette";
            this.toolbarPaletteToolStripMenuItem.Click += new System.EventHandler(this.toolbarPaletteToolStripMenuItem_Click);
            // 
            // 帮助ToolStripMenuItem
            // 
            this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            this.帮助ToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.帮助ToolStripMenuItem.Text = "帮助";
            this.帮助ToolStripMenuItem.Click += new System.EventHandler(this.帮助ToolStripMenuItem_Click);
            // 
            // axTOCControl1
            // 
            this.axTOCControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axTOCControl1.Location = new System.Drawing.Point(0, 0);
            this.axTOCControl1.Name = "axTOCControl1";
            this.axTOCControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axTOCControl1.OcxState")));
            this.axTOCControl1.Size = new System.Drawing.Size(163, 396);
            this.axTOCControl1.TabIndex = 5;
            this.axTOCControl1.OnDoubleClick += new ESRI.ArcGIS.Controls.ITOCControlEvents_Ax_OnDoubleClickEventHandler(this.axTOCControl1_OnDoubleClick);
            this.axTOCControl1.OnMouseDown += new ESRI.ArcGIS.Controls.ITOCControlEvents_Ax_OnMouseDownEventHandler(this.axTOCControl1_OnMouseDown);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 448);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(793, 22);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("微软雅黑", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(626, 396);
            this.tabControl1.TabIndex = 7;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.axMapControl1);
            this.tabPage1.Font = new System.Drawing.Font("微软雅黑", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(618, 370);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "地图视图";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // axMapControl1
            // 
            this.axMapControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axMapControl1.Location = new System.Drawing.Point(3, 3);
            this.axMapControl1.Name = "axMapControl1";
            this.axMapControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axMapControl1.OcxState")));
            this.axMapControl1.Size = new System.Drawing.Size(612, 364);
            this.axMapControl1.TabIndex = 0;
            this.axMapControl1.OnExtentUpdated += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnExtentUpdatedEventHandler(this.axMapControl1_OnExtentUpdated);
            this.axMapControl1.OnMapReplaced += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMapReplacedEventHandler(this.axMapControl1_OnMapReplaced);
            this.axMapControl1.OnMouseDown += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMouseDownEventHandler(this.axMapControl1_OnMouseDown);
            this.axMapControl1.OnAfterDraw += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnAfterDrawEventHandler(this.axMapControl1_OnAfterDraw);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.axPageLayoutControl1);
            this.tabPage2.Font = new System.Drawing.Font("微软雅黑", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(618, 370);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "布局视图";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // axPageLayoutControl1
            // 
            this.axPageLayoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axPageLayoutControl1.Location = new System.Drawing.Point(3, 3);
            this.axPageLayoutControl1.Name = "axPageLayoutControl1";
            this.axPageLayoutControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axPageLayoutControl1.OcxState")));
            this.axPageLayoutControl1.Size = new System.Drawing.Size(612, 364);
            this.axPageLayoutControl1.TabIndex = 0;
            this.axPageLayoutControl1.OnPageLayoutReplaced += new ESRI.ArcGIS.Controls.IPageLayoutControlEvents_Ax_OnPageLayoutReplacedEventHandler(this.axPageLayoutControl1_OnPageLayoutReplaced);
            this.axPageLayoutControl1.OnAfterDraw += new ESRI.ArcGIS.Controls.IPageLayoutControlEvents_Ax_OnAfterDrawEventHandler(this.axPageLayoutControl1_OnAfterDraw);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 52);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.axTOCControl1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer1.Size = new System.Drawing.Size(793, 396);
            this.splitContainer1.SplitterDistance = 163;
            this.splitContainer1.TabIndex = 8;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.checkBox1.Location = new System.Drawing.Point(595, 2);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(96, 21);
            this.checkBox1.TabIndex = 9;
            this.checkBox1.Text = "定制工具条...";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(707, 1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(58, 22);
            this.button1.TabIndex = 10;
            this.button1.Text = "鹰眼";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(793, 470);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.axToolbarControl1);
            this.Controls.Add(this.axLicenseControl1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "ArcGIS Engine System";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.axLicenseControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axToolbarControl1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axTOCControl1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axMapControl1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axPageLayoutControl1)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ESRI.ArcGIS.Controls.AxLicenseControl axLicenseControl1;
        private ESRI.ArcGIS.Controls.AxToolbarControl axToolbarControl1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuNewDoc;
        private System.Windows.Forms.ToolStripMenuItem menuOpenDoc;
        private System.Windows.Forms.ToolStripMenuItem menuSaveDoc;
        private System.Windows.Forms.ToolStripMenuItem menuSaveAs;
        private System.Windows.Forms.ToolStripMenuItem menuExitApp;
        private ESRI.ArcGIS.Controls.AxTOCControl axTOCControl1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private ESRI.ArcGIS.Controls.AxMapControl axMapControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private ESRI.ArcGIS.Controls.AxPageLayoutControl axPageLayoutControl1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem AddData;
        private System.Windows.Forms.ToolStripMenuItem mapControl控件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 载入文档ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 绘制图形元素ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 改变地图显示范围拉框ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem 数据选择拉多边形ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 线转元素ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 矩形元素ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 圆形元素ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 多边形元素ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pageLayoutControl控件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 载入文档ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 绘制元素SamplesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem borderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backgroundToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shadowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mapGridToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pageLayoutControl与ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tOCControl控件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolbarControl控件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem 相应功能查看帮助文档ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 驻留命令sampleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新建地图文档ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolbarMenuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolbarPaletteToolStripMenuItem;
    }
}

