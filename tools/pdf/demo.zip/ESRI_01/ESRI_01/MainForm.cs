﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.SystemUI;
using ESRI_01;
using rpaulo.toolbar;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.CartoUI;

namespace lesson1._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //浮动效果
            //ToolBarManager toolbarManager = new ToolBarManager(this, this);
            //toolbarManager.AddControl(axToolbarControl1, DockStyle.Top);
            //toolbarManager.AddControl(axMapControl1, DockStyle.Fill);
            //toolbarManager.AddControl(axTOCControl1, DockStyle.Left);
        }

        private string m_mapDocumentName = string.Empty;    //文件名称

        //右键菜单
        IToolbarMenu m_TOCMapMenu = new ToolbarMenu();
        IToolbarMenu m_TOCLayerMenu = new ToolbarMenu();
        IToolbarMenu m_ReferenceScale = new ToolbarMenu();
        IToolbarMenu m_toolbarMenu = new ToolbarMenu();

        ICustomizeDialog m_CustomizeDialog = new CustomizeDialog();
        ICustomizeDialogEvents_OnStartDialogEventHandler startDialogE;
        ICustomizeDialogEvents_OnCloseDialogEventHandler closeDialogE;

        OverviewFrm pOverview;

        //打开文件
        private void 打开文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ICommand command = new ControlsOpenDocCommand();
            command.OnCreate(axMapControl1.Object);
            command.OnClick();
        }

        //保存文件
        private void 保存文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(m_mapDocumentName);
            //execute Save Document command
            if (axMapControl1.CheckMxFile(m_mapDocumentName))
            {
                //create a new instance of a MapDocument
                IMapDocument mapDoc = new MapDocumentClass();
                mapDoc.Open(m_mapDocumentName, string.Empty);

                //Make sure that the MapDocument is not readonly
                if (mapDoc.get_IsReadOnly(m_mapDocumentName))
                {
                    MessageBox.Show("Map document is read only!");
                    mapDoc.Close();
                    return;
                }

                //Replace its contents with the current map
                mapDoc.ReplaceContents((IMxdContents)axMapControl1.Map);

                //save the MapDocument in order to persist it
                mapDoc.Save(mapDoc.UsesRelativePaths, false);

                //close the MapDocument
                mapDoc.Close();
            }
        }

        //另存文件
        private void 另存为ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ICommand command = new ControlsSaveAsDocCommand();
            command.OnCreate(axMapControl1.Object);
            command.OnClick();
        }

        //新建文件
        private void 新建文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ICommand command = new CreateNewDocument();
            command.OnCreate(axMapControl1.Object);
            command.OnClick();
        }

        //窗体加载
        private void Form1_Load(object sender, EventArgs e)
        {
            CopyMap();  //布局与视图的同步

            //添加TOCLayer右键菜单项
            m_TOCLayerMenu.Caption = "Sub Menu";
            m_TOCLayerMenu.AddItem(new OpenAttributeTableCmd(), 0, 0, false, esriCommandStyles.esriCommandStyleIconAndText);
            m_TOCLayerMenu.AddItem(new RemoveLayerCmd(), 0, 1, true, esriCommandStyles.esriCommandStyleIconAndText);

            m_TOCLayerMenu.AddItem(new ScaleThresholdCmd(), 1, 2, true, esriCommandStyles.esriCommandStyleTextOnly);
            m_TOCLayerMenu.AddItem(new ScaleThresholdCmd(), 2, 3, false, esriCommandStyles.esriCommandStyleTextOnly);
            m_TOCLayerMenu.AddItem(new ScaleThresholdCmd(), 3, 4, false, esriCommandStyles.esriCommandStyleTextOnly);

            m_TOCLayerMenu.AddItem(new LayerSelectable(), 1, 5, true, esriCommandStyles.esriCommandStyleTextOnly);
            m_TOCLayerMenu.AddItem(new LayerSelectable(), 2, 6, false, esriCommandStyles.esriCommandStyleTextOnly);

            m_TOCLayerMenu.AddItem(new ZoomToLayerCmd(), 0, 7, true, esriCommandStyles.esriCommandStyleTextOnly);
            m_TOCLayerMenu.AddItem(new LayerPropertiesCmd(), 0, 8, true, esriCommandStyles.esriCommandStyleTextOnly);

            m_TOCLayerMenu.SetHook(axMapControl1);

            //添加TOCMap右键菜单项
            m_TOCMapMenu.AddItem(new AddDataCmd(), 0, 0, false, esriCommandStyles.esriCommandStyleIconAndText);

            m_ReferenceScale.Caption = "参考比例尺";
            m_TOCMapMenu.AddSubMenu(m_ReferenceScale, 1, true);

            m_ReferenceScale.AddItem(new SetReferenceScaleCmd(), 0, 0, false, esriCommandStyles.esriCommandStyleIconAndText);
            m_ReferenceScale.AddItem(new ClearReferenceScaleCmd(), 0, 1, false, esriCommandStyles.esriCommandStyleIconAndText);
            m_ReferenceScale.AddItem(new ZoomToReferenceScaleCmd(), 0, 2, false, esriCommandStyles.esriCommandStyleIconAndText);

            m_TOCMapMenu.AddItem(new TurnAllLayersOnCmd(), 0, 2, true, esriCommandStyles.esriCommandStyleIconAndText);
            m_TOCMapMenu.AddItem(new TurnAllLayersOffCmd(), 0, 3, false, esriCommandStyles.esriCommandStyleIconAndText);

            m_TOCMapMenu.SetHook(axMapControl1);

            //添加MapControl右键菜单项
            m_toolbarMenu.AddItem(new ClearCurrentTool(), 0, -1, false, esriCommandStyles.esriCommandStyleTextOnly);
            m_toolbarMenu.AddItem(new ClearFeatureSelection(), 0, -1, false, esriCommandStyles.esriCommandStyleTextOnly);
            m_toolbarMenu.AddItem(new ZoomIn3XCMD(), 0, -1, false, esriCommandStyles.esriCommandStyleTextOnly);
            m_toolbarMenu.AddItem(new Refresh(), 0, -1, true, esriCommandStyles.esriCommandStyleTextOnly);

            m_toolbarMenu.SetHook(axMapControl1);

            CreateCustomizeDialog();
        }

        private void CreateCustomizeDialog()
        {
            ICustomizeDialogEvents_Event pCustomizeDialogEvent = m_CustomizeDialog as ICustomizeDialogEvents_Event;
            startDialogE = new ICustomizeDialogEvents_OnStartDialogEventHandler(OnStartDialogHandler);
            pCustomizeDialogEvent.OnStartDialog += startDialogE;
            closeDialogE = new ICustomizeDialogEvents_OnCloseDialogEventHandler(OnCloseDialogHandler);
            pCustomizeDialogEvent.OnCloseDialog += closeDialogE;
            m_CustomizeDialog.SetDoubleClickDestination(axToolbarControl1);
        }

        private void OnStartDialogHandler()
        {
            axToolbarControl1.Customize = true;
        }

        private void OnCloseDialogHandler()
        {
            axToolbarControl1.Customize = false;
            checkBox1.Checked = false;
        }

        //地图替换触发
        private void axMapControl1_OnMapReplaced(object sender, IMapControlEvents2_OnMapReplacedEvent e)
        {
            CopyMap();
        }

        //将地图从视图拷贝到布局的函数
        private void CopyMap()
        {
            IObjectCopy pCopy = new ObjectCopy();
            object copyMap = axMapControl1.ActiveView.FocusMap;
            object copyToMap = axPageLayoutControl1.ActiveView.FocusMap;
            pCopy.Overwrite(copyMap, ref copyToMap);
            axPageLayoutControl1.ActiveView.Refresh();
        }

        //地图发生拖拽后触发事件，保持两者的同步
        private void axMapControl1_OnAfterDraw(object sender, IMapControlEvents2_OnAfterDrawEvent e)
        {
            IActiveView pActiveView = axPageLayoutControl1.ActiveView.FocusMap as IActiveView;
            IScreenDisplay pScreenDisplay = pActiveView.ScreenDisplay;
            IDisplayTransformation pDisplayTransformation = pScreenDisplay.DisplayTransformation;
            pDisplayTransformation.VisibleBounds = axMapControl1.Extent;
            pActiveView.Refresh();
        }

        //退出程序
        private void menuExitApp_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //目录上点击左右键
        private void axTOCControl1_OnMouseDown(object sender, ITOCControlEvents_OnMouseDownEvent e)
        {
            esriTOCControlItem item = esriTOCControlItem.esriTOCControlItemNone;
            IBasicMap map = null;
            ILayer layer = null;
            object other = null;
            object index = null;

            axTOCControl1.HitTest(e.x, e.y, ref item, ref map, ref layer, ref other, ref index);
            if (e.button == 1)
            {
                ILegendClass pLegend = new LegendClassClass();
                ISymbol symbol = null;
                if (other is ILegendGroup && (int)index != -1)
                {
                    pLegend = ((ILegendGroup)other).get_Class((int)index) as ILegendClass;
                    symbol = pLegend.Symbol;
                }

                //esriSymbologyStyleClass pSymbologyStyle = esriSymbologyStyleClass.esriStyleClassMarkerSymbols;
                //if (symbol is IMarkerSymbol)
                //{
                //    pSymbologyStyle = esriSymbologyStyleClass.esriStyleClassMarkerSymbols;
                //}
                //if (symbol is ILineSymbol)
                //{
                //    pSymbologyStyle = esriSymbologyStyleClass.esriStyleClassLineSymbols;
                //}
                //if (symbol is IFillSymbol)
                //{
                //    pSymbologyStyle = esriSymbologyStyleClass.esriStyleClassFillSymbols;
                //}

                SymbologyFrmLee frm = new SymbologyFrmLee(pLegend, layer);
                frm.ShowDialog();
                symbol = frm.pStyleGalleryItem.Item as ISymbol;
                pLegend.Symbol = symbol;
                axMapControl1.Refresh(esriViewDrawPhase.esriViewGeography, null, null);
            }

            if (e.button == 2)
            {
                if (item == esriTOCControlItem.esriTOCControlItemMap)
                {
                    axMapControl1.CustomProperty = map;     //其实都没用到诶！
                    m_TOCMapMenu.PopupMenu(e.x, e.y, axTOCControl1.hWnd);
                }
                else if (item == esriTOCControlItem.esriTOCControlItemLayer)
                {
                    axMapControl1.CustomProperty = layer;   //传入工具中的重要信息！
                    m_TOCLayerMenu.PopupMenu(e.x, e.y, axTOCControl1.hWnd);
                }
            }
        }

        //添加数据
        private void AddData_Click(object sender, EventArgs e)
        {
            ICommand command = new ControlsAddDataCommand();
            command.OnCreate(axMapControl1.Object);
            command.OnClick();
        }

        private void axMapControl1_OnMouseDown(object sender, IMapControlEvents2_OnMouseDownEvent e)
        {
            if (e.button == 1)
            {

            }
            if (e.button == 2)
            {
                m_toolbarMenu.PopupMenu(e.x, e.y, axMapControl1.hWnd);
            }
        }
        ITool pMapTool = null;
        ITool pPageLayoutTool = null;
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 0)
            {
                if (axPageLayoutControl1.CurrentTool != null)
                    pPageLayoutTool = axPageLayoutControl1.CurrentTool;

                axToolbarControl1.SetBuddyControl(axMapControl1);

                if (axMapControl1.CurrentTool == null)
                    axMapControl1.CurrentTool = pMapTool;
            }
            else
            {
                if (axMapControl1.CurrentTool != null)
                    pMapTool = axMapControl1.CurrentTool;

                axToolbarControl1.SetBuddyControl(axPageLayoutControl1);

                if (axPageLayoutControl1.CurrentTool == null)
                    axPageLayoutControl1.CurrentTool = pPageLayoutTool;
            }
        }

        private void axPageLayoutControl1_OnAfterDraw(object sender, IPageLayoutControlEvents_OnAfterDrawEvent e)
        {
            IActiveView pActiveView = axPageLayoutControl1.ActiveView.FocusMap as IActiveView;
            IScreenDisplay pScreenDisplay = pActiveView.ScreenDisplay;
            IDisplayTransformation pDisplayTransformation = pScreenDisplay.DisplayTransformation;
            axMapControl1.Extent = pDisplayTransformation.VisibleBounds;
            axMapControl1.ActiveView.Refresh();
        }

        private void 载入文档ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "map documents(*.mxd)|*.mxd";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                axMapControl1.LoadMxFile(ofd.FileName);
            }
        }

        private void 线转元素ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ICommand command = new CreatePolylineTool();
            command.OnCreate(axMapControl1.Object);
            axMapControl1.CurrentTool = command as ESRI.ArcGIS.SystemUI.ITool;
        }

        private void 矩形元素ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ICommand command = new CreateRectangleTool();
            command.OnCreate(axMapControl1.Object);
            axMapControl1.CurrentTool = command as ESRI.ArcGIS.SystemUI.ITool;
        }

        private void 圆形元素ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ICommand command = new CreateCircleTool();
            command.OnCreate(axMapControl1.Object);
            axMapControl1.CurrentTool = command as ESRI.ArcGIS.SystemUI.ITool;
        }

        private void 多边形元素ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ICommand command = new CreatePolygonTool();
            command.OnCreate(axMapControl1.Object);
            axMapControl1.CurrentTool = command as ESRI.ArcGIS.SystemUI.ITool;
        }

        private void 改变地图显示范围拉框ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ICommand command = new ChangeExtent();
            command.OnCreate(axMapControl1.Object);
            axMapControl1.CurrentTool = command as ESRI.ArcGIS.SystemUI.ITool;
        }

        private void 数据选择拉多边形ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ICommand command = new SelectByShapeTool();
            command.OnCreate(axMapControl1.Object);
            axMapControl1.CurrentTool = command as ESRI.ArcGIS.SystemUI.ITool;
        }

        private void 载入文档ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "map document(*.mxd)|*.mxd";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                axPageLayoutControl1.LoadMxFile(ofd.FileName);
            }
        }

        private void axPageLayoutControl1_OnPageLayoutReplaced(object sender, IPageLayoutControlEvents_OnPageLayoutReplacedEvent e)
        {
            IObjectCopy pObjectCopy = new ObjectCopy();
            object CopyMap = axPageLayoutControl1.ActiveView.FocusMap;
            object CopyToMap = axMapControl1.Map;
            pObjectCopy.Overwrite(CopyMap, ref CopyToMap);
        }

        private void borderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IActiveView pActiveView = axPageLayoutControl1.PageLayout as IActiveView;
            IMap pMap = pActiveView.FocusMap;
            IGraphicsContainer pGraphicsContainer = pActiveView as IGraphicsContainer;
            IMapFrame pMapFrame = pGraphicsContainer.FindFrame(pMap) as IMapFrame;
            IStyleSelector pStyleSelector = new BorderSelector();
            if (pStyleSelector.DoModal(axPageLayoutControl1.hWnd))
            {
                IBorder PBorder = pStyleSelector.GetStyle(0) as IBorder;
                pMapFrame.Border = PBorder;
            }
            axPageLayoutControl1.Refresh(esriViewDrawPhase.esriViewBackground, null, null);
        }

        private void backgroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IActiveView pActiveView = axPageLayoutControl1.PageLayout as IActiveView;
            IMap pMap = pActiveView.FocusMap;
            IGraphicsContainer pGraphicsContainer = pActiveView as IGraphicsContainer;
            IMapFrame pMapFrame = pGraphicsContainer.FindFrame(pMap) as IMapFrame;
            IStyleSelector pStyleSelector = new BackgroundSelector();
            if (pStyleSelector.DoModal(axPageLayoutControl1.hWnd))
            {
                IBackground pBackground = pStyleSelector.GetStyle(0) as IBackground;
                pMapFrame.Background = pBackground;
            }
            pActiveView.Refresh();
        }

        private void shadowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IActiveView pActiveView = axPageLayoutControl1.PageLayout as IActiveView;
            IMap pMap = pActiveView.FocusMap;
            IGraphicsContainer pGraphicsContainer = pActiveView as IGraphicsContainer;
            IMapFrame pMapFrame = pGraphicsContainer.FindFrame(pMap) as IMapFrame;
            IStyleSelector pStyleSelector = new ShadowSelector();
            if (pStyleSelector.DoModal(axPageLayoutControl1.hWnd))
            {
                IShadow pShadow = pStyleSelector.GetStyle(0) as IShadow;
                IFrameProperties pFrameProperties = pMapFrame as IFrameProperties;
                pFrameProperties.Shadow = pShadow;
            }
            pActiveView.Refresh();
        }

        private void mapGridToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IActiveView pActiveView = axPageLayoutControl1.PageLayout as IActiveView;
            IMap pMap = pActiveView.FocusMap;
            IGraphicsContainer pGraphicsContainer = pActiveView as IGraphicsContainer;
            IMapFrame pMapFrame = pGraphicsContainer.FindFrame(pMap) as IMapFrame;
            IStyleSelector pStyleSelector = new MapGridSelector();
            if (pStyleSelector.DoModal(axPageLayoutControl1.hWnd))
            {
                IMapGrid pMapGrid = pStyleSelector.GetStyle(0) as IMapGrid;
                IMapGrids pMapGrids = pMapFrame as IMapGrids;
                if (pMapGrid == null)
                {
                    return;
                }
                pMapGrids.AddMapGrid(pMapGrid);
            }
            pActiveView.Refresh();
        }

        private void 新建地图文档ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            axToolbarControl1.AddItem(new CreateNewDocument(), 0, 0, false, 0, esriCommandStyles.esriCommandStyleIconOnly);
        }

        private void toolbarMenuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IToolbarMenu2 toolbarMenu = new ToolbarMenuClass();
            toolbarMenu.Caption = "ToolbarMenu";
            toolbarMenu.AddItem(new ClearFeatureSelection(), 0, -1, false, esriCommandStyles.esriCommandStyleIconAndText);
            toolbarMenu.AddItem(new ZoomIn3XCMD(), 0, -1, false, esriCommandStyles.esriCommandStyleIconAndText);
            toolbarMenu.AddItem(new Refresh(), 0, -1, false, esriCommandStyles.esriCommandStyleIconAndText);

            axToolbarControl1.AddMenuItem(toolbarMenu, -1, false, 0);
        }

        private void toolbarPaletteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IToolbarPalette pToolbarPalette = new ToolbarPalette();
            pToolbarPalette.Caption = "ToolbarPalette";
            pToolbarPalette.AddItem(new ClearCurrentTool(), 0, -1);
            pToolbarPalette.AddItem(new CreatePolygonTool(), 0, -1);

            axToolbarControl1.AddItem(pToolbarPalette, 0, -1, true, 0, esriCommandStyles.esriCommandStyleIconOnly);
        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, Application.StartupPath + @"\帮助文档.chm");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false)
            {
                m_CustomizeDialog.CloseDialog();
            }
            else
            {
                m_CustomizeDialog.StartDialog(axToolbarControl1.hWnd);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            IHookHelper hookHelper = new HookHelper();
            hookHelper.Hook = axMapControl1.Object;
            pOverview = new OverviewFrm(hookHelper);
            pOverview.Show();
        }

        private void axMapControl1_OnExtentUpdated(object sender, IMapControlEvents2_OnExtentUpdatedEvent e)
        {
            IEnvelope pEnv = e.newEnvelope as IEnvelope;
            IGraphicsContainer pGraphicsContainer = pOverview.axMapControl1.Map as IGraphicsContainer;
            IActiveView pActiveView = pGraphicsContainer as IActiveView;
            pGraphicsContainer.DeleteAllElements();

            ISimpleLineSymbol pSimpleLineSymbol = new SimpleLineSymbol();
            pSimpleLineSymbol.Width = 1;
            IRgbColor pColor = new RgbColor();
            pColor.Red = 255;
            pSimpleLineSymbol.Color = pColor;

            ISimpleFillSymbol pSimpleFillSymbol = new SimpleFillSymbol();
            pSimpleFillSymbol.Outline = pSimpleLineSymbol;
            pColor.Transparency = 0;
            pSimpleFillSymbol.Color = pColor;

            IElement pElement = new RectangleElement();
            pElement.Geometry = pEnv;

            IFillShapeElement pFillShapeElement = pElement as IFillShapeElement;
            pFillShapeElement.Symbol = pSimpleFillSymbol;

            pElement = pFillShapeElement as IElement;

            pGraphicsContainer.AddElement(pElement, 0);
            pActiveView.PartialRefresh(esriViewDrawPhase.esriViewGraphics, null, null);
        }

        private void axTOCControl1_OnDoubleClick(object sender, ITOCControlEvents_OnDoubleClickEvent e)
        {
            esriTOCControlItem itemType = esriTOCControlItem.esriTOCControlItemNone;

            IBasicMap basicMap = null;

            ILayer layer = null;

            object unk = null;

            object data = null;

            axTOCControl1.HitTest(e.x, e.y, ref itemType, ref basicMap, ref layer, ref unk, ref data);

            if (e.button == 1)
            {

                if (itemType == esriTOCControlItem.esriTOCControlItemLegendClass)
                {

                    //取得图例

                    ILegendClass pLegendClass = ((ILegendGroup)unk).get_Class((int)data);

                    //创建符号选择器SymbolSelector实例

                    SymbolSelectorFrm SymbolSelectorFrm = new SymbolSelectorFrm(pLegendClass, layer);

                    if (SymbolSelectorFrm.ShowDialog() == DialogResult.OK)
                    {

                        //局部更新主Map控件

                        axMapControl1.ActiveView.PartialRefresh(esriViewDrawPhase.esriViewGeography, null, null);

                        //设置新的符号

                        pLegendClass.Symbol = SymbolSelectorFrm.pSymbol;

                        //更新主Map控件和图层控件

                        this.axMapControl1.ActiveView.Refresh();

                        this.axTOCControl1.Refresh();

                    }

                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button1.PerformClick();
        }
    }
}
