﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geometry;

namespace ESRI_01
{
    public partial class OverviewFrm : Form
    {
        IMapControl4 m_mapControl;
        IMap m_map;

        public OverviewFrm(IHookHelper hook)
        {
            InitializeComponent();
            m_mapControl = hook.Hook as IMapControl4;
            m_map = m_mapControl.Map;
        }

        private void axMapControl1_OnMouseDown(object sender, ESRI.ArcGIS.Controls.IMapControlEvents2_OnMouseDownEvent e)
        {
            IPoint pPoint = new ESRI.ArcGIS.Geometry.Point();
            pPoint.PutCoords(e.mapX, e.mapY);
            m_mapControl.CenterAt(pPoint);
        }

        private void OverviewFrm_Load(object sender, EventArgs e)
        {
            for (int i = m_mapControl.LayerCount - 1; i >= 0 ;i-- )
            {
                axMapControl1.AddLayer(m_mapControl.get_Layer(i));
            }
            axMapControl1.Refresh();
        }
    }
}
