﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using ESRI.ArcGIS.ADF.BaseClasses;
using ESRI.ArcGIS.ADF.CATIDs;
using ESRI.ArcGIS.Controls;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.SystemUI;

namespace ESRI_01
{
    /// <summary>
    /// Summary description for ScaleThresholdCmd.
    /// </summary>
    [Guid("41b9d7ee-ba25-47d1-9644-f9eca4243c34")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("ESRI_01.ScaleThresholdCmd")]
    public sealed class ScaleThresholdCmd : BaseCommand, ICommandSubType
    {
        #region COM Registration Function(s)
        [ComRegisterFunction()]
        [ComVisible(false)]
        static void RegisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryRegistration(registerType);

            //
            // TODO: Add any COM registration code here
            //
        }

        [ComUnregisterFunction()]
        [ComVisible(false)]
        static void UnregisterFunction(Type registerType)
        {
            // Required for ArcGIS Component Category Registrar support
            ArcGISCategoryUnregistration(registerType);

            //
            // TODO: Add any COM unregistration code here
            //
        }

        #region ArcGIS Component Category Registrar generated code
        /// <summary>
        /// Required method for ArcGIS Component Category registration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryRegistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Register(regKey);

        }
        /// <summary>
        /// Required method for ArcGIS Component Category unregistration -
        /// Do not modify the contents of this method with the code editor.
        /// </summary>
        private static void ArcGISCategoryUnregistration(Type registerType)
        {
            string regKey = string.Format("HKEY_CLASSES_ROOT\\CLSID\\{{{0}}}", registerType.GUID);
            ControlsCommands.Unregister(regKey);

        }

        #endregion
        #endregion

        private IHookHelper m_hookHelper = null;
        private IMapControl4 m_mapControl = null;
        private long m_subType;

        public ScaleThresholdCmd()
        {
        }

        #region Overriden Class Methods

        /// <summary>
        /// Occurs when this command is created
        /// </summary>
        /// <param name="hook">Instance of the application</param>
        /// 

        public override string Caption
        {
            get
            {
                if (m_subType == 1)
                {
                    return "设置最大显示比例尺";
                }
                else if (m_subType == 2)
                {
                    return "设置最小显示比例尺";
                }
                else
                {
                    return "取消比例尺显示限制";
                }
            }
        }

        public override bool Enabled
        {
            get
            {
                bool enabled = true;
                ILayer layer = (ILayer)m_mapControl.CustomProperty;

                if (m_subType == 3)
                {
                    if ((layer.MaximumScale == 0) && (layer.MinimumScale == 0))
                    {
                        enabled = false;
                    }
                }
                return enabled;
            }
        }

        public override void OnCreate(object hook)
        {
            if (hook is IMapControl4)
                m_mapControl = (IMapControl4)hook;
        }

        /// <summary>
        /// Occurs when this command is clicked
        /// </summary>
        public override void OnClick()
        {
            // TODO: Add ScaleThresholdCmd.OnClick implementation
            m_mapControl = m_hookHelper.Hook as IMapControl4;
            IMap map = m_mapControl.Map;
            ILayer layer = m_mapControl.CustomProperty as ILayer;
            if (m_subType == 1)
            {
                layer.MaximumScale = map.MapScale;
            }
            else if (m_subType == 2)
            {
                layer.MinimumScale = map.MapScale;
            }
            else if (m_subType == 3)
            {
                layer.MaximumScale = 0;
                layer.MinimumScale = 0;
            }
        }

        #endregion

        #region ICommandSubType 成员

        public int GetCount()
        {
            return 3;
        }

        public void SetSubType(int SubType)
        {
            m_subType = SubType;
        }

        #endregion
    }
}
