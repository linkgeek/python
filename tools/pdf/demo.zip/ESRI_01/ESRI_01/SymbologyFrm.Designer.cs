﻿namespace ESRI_01
{
    partial class SymbologyFrmLee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SymbologyFrmLee));
            this.axSymbologyControl1 = new ESRI.ArcGIS.Controls.AxSymbologyControl();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btColor = new System.Windows.Forms.Button();
            this.btOutlineColor = new System.Windows.Forms.Button();
            this.cbOutlineColor = new System.Windows.Forms.ComboBox();
            this.cbColor = new System.Windows.Forms.ComboBox();
            this.nudAngle = new System.Windows.Forms.NumericUpDown();
            this.nudWidth = new System.Windows.Forms.NumericUpDown();
            this.lbOutlineColor = new System.Windows.Forms.Label();
            this.lbAngle = new System.Windows.Forms.Label();
            this.lbWidth = new System.Windows.Forms.Label();
            this.lbColor = new System.Windows.Forms.Label();
            this.btMore = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.axSymbologyControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAngle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudWidth)).BeginInit();
            this.SuspendLayout();
            // 
            // axSymbologyControl1
            // 
            this.axSymbologyControl1.Location = new System.Drawing.Point(17, 12);
            this.axSymbologyControl1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.axSymbologyControl1.Name = "axSymbologyControl1";
            this.axSymbologyControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axSymbologyControl1.OcxState")));
            this.axSymbologyControl1.Size = new System.Drawing.Size(495, 482);
            this.axSymbologyControl1.TabIndex = 2;
            this.axSymbologyControl1.OnItemSelected += new ESRI.ArcGIS.Controls.ISymbologyControlEvents_Ax_OnItemSelectedEventHandler(this.axSymbologyControl1_OnItemSelected);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(576, 401);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 35);
            this.button2.TabIndex = 3;
            this.button2.Text = "取消";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(576, 453);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(98, 35);
            this.button3.TabIndex = 3;
            this.button3.Text = "确定";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(3, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(183, 104);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Location = new System.Drawing.Point(529, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(189, 129);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "预览";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btColor);
            this.groupBox2.Controls.Add(this.btOutlineColor);
            this.groupBox2.Controls.Add(this.cbOutlineColor);
            this.groupBox2.Controls.Add(this.cbColor);
            this.groupBox2.Controls.Add(this.nudAngle);
            this.groupBox2.Controls.Add(this.nudWidth);
            this.groupBox2.Controls.Add(this.lbOutlineColor);
            this.groupBox2.Controls.Add(this.lbAngle);
            this.groupBox2.Controls.Add(this.lbWidth);
            this.groupBox2.Controls.Add(this.lbColor);
            this.groupBox2.Location = new System.Drawing.Point(529, 175);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(189, 155);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "选项";
            // 
            // btColor
            // 
            this.btColor.FlatAppearance.BorderSize = 0;
            this.btColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btColor.Location = new System.Drawing.Point(105, 37);
            this.btColor.Name = "btColor";
            this.btColor.Size = new System.Drawing.Size(50, 25);
            this.btColor.TabIndex = 4;
            this.btColor.UseVisualStyleBackColor = true;
            this.btColor.Visible = false;
            this.btColor.Click += new System.EventHandler(this.button1_Click);
            // 
            // btOutlineColor
            // 
            this.btOutlineColor.FlatAppearance.BorderSize = 0;
            this.btOutlineColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btOutlineColor.Location = new System.Drawing.Point(105, 112);
            this.btOutlineColor.Name = "btOutlineColor";
            this.btOutlineColor.Size = new System.Drawing.Size(50, 25);
            this.btOutlineColor.TabIndex = 3;
            this.btOutlineColor.UseVisualStyleBackColor = true;
            this.btOutlineColor.Visible = false;
            this.btOutlineColor.Click += new System.EventHandler(this.button4_Click);
            // 
            // cbOutlineColor
            // 
            this.cbOutlineColor.FormattingEnabled = true;
            this.cbOutlineColor.Location = new System.Drawing.Point(104, 111);
            this.cbOutlineColor.Name = "cbOutlineColor";
            this.cbOutlineColor.Size = new System.Drawing.Size(69, 28);
            this.cbOutlineColor.TabIndex = 2;
            this.cbOutlineColor.Visible = false;
            this.cbOutlineColor.MouseClick += new System.Windows.Forms.MouseEventHandler(this.comboBox3_MouseClick);
            // 
            // cbColor
            // 
            this.cbColor.FormattingEnabled = true;
            this.cbColor.Location = new System.Drawing.Point(104, 36);
            this.cbColor.Name = "cbColor";
            this.cbColor.Size = new System.Drawing.Size(69, 28);
            this.cbColor.TabIndex = 2;
            this.cbColor.Visible = false;
            this.cbColor.MouseClick += new System.Windows.Forms.MouseEventHandler(this.comboBox2_MouseClick);
            // 
            // nudAngle
            // 
            this.nudAngle.Location = new System.Drawing.Point(104, 112);
            this.nudAngle.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nudAngle.Name = "nudAngle";
            this.nudAngle.Size = new System.Drawing.Size(69, 26);
            this.nudAngle.TabIndex = 1;
            this.nudAngle.Visible = false;
            this.nudAngle.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // nudWidth
            // 
            this.nudWidth.Location = new System.Drawing.Point(104, 74);
            this.nudWidth.Name = "nudWidth";
            this.nudWidth.Size = new System.Drawing.Size(69, 26);
            this.nudWidth.TabIndex = 1;
            this.nudWidth.Visible = false;
            this.nudWidth.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // lbOutlineColor
            // 
            this.lbOutlineColor.AutoSize = true;
            this.lbOutlineColor.Location = new System.Drawing.Point(7, 115);
            this.lbOutlineColor.Name = "lbOutlineColor";
            this.lbOutlineColor.Size = new System.Drawing.Size(65, 20);
            this.lbOutlineColor.TabIndex = 0;
            this.lbOutlineColor.Text = "框线颜色";
            this.lbOutlineColor.Visible = false;
            // 
            // lbAngle
            // 
            this.lbAngle.AutoSize = true;
            this.lbAngle.Location = new System.Drawing.Point(7, 114);
            this.lbAngle.Name = "lbAngle";
            this.lbAngle.Size = new System.Drawing.Size(65, 20);
            this.lbAngle.TabIndex = 0;
            this.lbAngle.Text = "旋转角度";
            this.lbAngle.Visible = false;
            // 
            // lbWidth
            // 
            this.lbWidth.AutoSize = true;
            this.lbWidth.Location = new System.Drawing.Point(7, 76);
            this.lbWidth.Name = "lbWidth";
            this.lbWidth.Size = new System.Drawing.Size(65, 20);
            this.lbWidth.TabIndex = 0;
            this.lbWidth.Text = "框线宽度";
            this.lbWidth.Visible = false;
            // 
            // lbColor
            // 
            this.lbColor.AutoSize = true;
            this.lbColor.Location = new System.Drawing.Point(7, 37);
            this.lbColor.Name = "lbColor";
            this.lbColor.Size = new System.Drawing.Size(65, 20);
            this.lbColor.TabIndex = 0;
            this.lbColor.Text = "填充颜色";
            this.lbColor.Visible = false;
            // 
            // btMore
            // 
            this.btMore.Location = new System.Drawing.Point(576, 345);
            this.btMore.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btMore.Name = "btMore";
            this.btMore.Size = new System.Drawing.Size(98, 35);
            this.btMore.TabIndex = 3;
            this.btMore.Text = "更多符号";
            this.btMore.UseVisualStyleBackColor = true;
            this.btMore.Click += new System.EventHandler(this.btMore_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            this.contextMenuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.contextMenuStrip1_ItemClicked);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // SymbologyFrmLee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(733, 504);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btMore);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.axSymbologyControl1);
            this.Controls.Add(this.button2);
            this.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "SymbologyFrmLee";
            this.Load += new System.EventHandler(this.SymbologyFrm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.axSymbologyControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAngle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudWidth)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ESRI.ArcGIS.Controls.AxSymbologyControl axSymbologyControl1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbOutlineColor;
        private System.Windows.Forms.Label lbWidth;
        private System.Windows.Forms.Label lbColor;
        private System.Windows.Forms.ComboBox cbColor;
        private System.Windows.Forms.NumericUpDown nudWidth;
        private System.Windows.Forms.Button btOutlineColor;
        private System.Windows.Forms.ComboBox cbOutlineColor;
        private System.Windows.Forms.Button btColor;
        private System.Windows.Forms.NumericUpDown nudAngle;
        private System.Windows.Forms.Label lbAngle;
        private System.Windows.Forms.Button btMore;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}