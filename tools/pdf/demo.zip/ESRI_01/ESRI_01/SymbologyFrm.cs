﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Controls;
using System.IO;
using ESRI.ArcGIS.SystemUI;
using ESRI.ArcGIS.Display;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.Geometry;

namespace ESRI_01
{
    public partial class SymbologyFrmLee : Form
    {
        esriSymbologyStyleClass pStyleClass;
        public IStyleGalleryItem pStyleGalleryItem;
        ILegendClass pLegendClass;
        ILayer pLayer;
        bool contextMenuMoreSymbolInitiated = false;

        public SymbologyFrmLee(ILegendClass tempLegendClass, ILayer tempLayer)
        {
            InitializeComponent();
            pLegendClass = tempLegendClass;
            pLayer = tempLayer;
        }

        private void SymbologyFrm_Load(object sender, EventArgs e)
        {
            switch(((IFeatureLayer)pLayer).FeatureClass.ShapeType)
            {
                case esriGeometryType.esriGeometryPoint:
                    pStyleClass = esriSymbologyStyleClass.esriStyleClassMarkerSymbols;
                    lbColor.Visible = true;
                    lbWidth.Visible = true;
                    lbWidth.Text = "符号大小";
                    lbAngle.Visible = true;
                    btColor.Visible = true;
                    nudWidth.Visible = true;
                    cbColor.Visible = true;
                    nudAngle.Visible = true;
                    break;
                case esriGeometryType.esriGeometryPolyline:
                    pStyleClass = esriSymbologyStyleClass.esriStyleClassLineSymbols;
                    lbColor.Visible = true;
                    lbColor.Location = System.Drawing.Point.Add(lbColor.Location, new Size(0, 12));
                    lbWidth.Visible = true;
                    lbWidth.Location = System.Drawing.Point.Add(lbWidth.Location, new Size(0, 24));
                    lbWidth.Text = "线符号粗细";
                    btColor.Visible = true;
                    cbColor.Visible = true;
                    btColor.Location = System.Drawing.Point.Add(btColor.Location, new Size(0, 12));
                    cbColor.Location = System.Drawing.Point.Add(cbColor.Location, new Size(0, 12));
                    nudWidth.Visible = true;
                    nudWidth.Location = System.Drawing.Point.Add(nudWidth.Location, new Size(0, 24));
                    break;
                case esriGeometryType.esriGeometryPolygon:
                    pStyleClass = esriSymbologyStyleClass.esriStyleClassFillSymbols;
                    lbColor.Visible = true;
                    lbWidth.Visible = true;
                    lbWidth.Text = "框线宽度";
                    lbOutlineColor.Visible = true;
                    btColor.Visible = true;
                    btOutlineColor.Visible = true;
                    nudWidth.Visible = true;
                    cbColor.Visible = true;
                    cbOutlineColor.Visible = true;
                    break;
                default:
                    this.Close();
                    break;
            }

            string strInstall = @"C:\Program Files (x86)\ArcGIS";
            string stylePath = strInstall + @"\Styles\ESRI.ServerStyle";
            axSymbologyControl1.LoadStyleFile(stylePath);
            axSymbologyControl1.StyleClass = pStyleClass;

            IStyleGalleryItem pCurrentStyleGalleryItem = new StyleGalleryItem();
            pCurrentStyleGalleryItem.Name = "当前符号";
            pCurrentStyleGalleryItem.Item = pLegendClass.Symbol;
            ISymbologyStyleClass pSymbologyStyleClass = axSymbologyControl1.GetStyleClass(axSymbologyControl1.StyleClass);
            pSymbologyStyleClass.AddItem(pCurrentStyleGalleryItem, 0);
            pSymbologyStyleClass.SelectItem(0);
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pStyleGalleryItem = null;
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void PreviewPicture()
        {
            ISymbologyStyleClass pSymbologyStyle = axSymbologyControl1.GetStyleClass(axSymbologyControl1.StyleClass);
            stdole.IPictureDisp picture = pSymbologyStyle.PreviewItem(pStyleGalleryItem, pictureBox1.Width, pictureBox1.Height);
            Image image = Image.FromHbitmap(new IntPtr(picture.Handle));
            pictureBox1.Image = image;
        }

        private void axSymbologyControl1_OnItemSelected(object sender, ISymbologyControlEvents_OnItemSelectedEvent e)
        {
            pStyleGalleryItem = e.styleGalleryItem as IStyleGalleryItem;
            PreviewPicture();

            if (((IFeatureLayer)pLayer).FeatureClass.ShapeType == esriGeometryType.esriGeometryPoint)
            {
                IRgbColor pColor = ((IMarkerSymbol)pStyleGalleryItem.Item).Color as IRgbColor;
                btColor.BackColor = Color.FromArgb(pColor.Red, pColor.Green, pColor.Blue);
                nudAngle.Value = Convert.ToDecimal(((IMarkerSymbol)pStyleGalleryItem.Item).Angle);
                nudWidth.Value = Convert.ToDecimal(((IMarkerSymbol)pStyleGalleryItem.Item).Size);
            }

            if (((IFeatureLayer)pLayer).FeatureClass.ShapeType == esriGeometryType.esriGeometryPolyline)
            {
                IRgbColor pColor = ((ILineSymbol)pStyleGalleryItem.Item).Color as IRgbColor;
                btColor.BackColor = Color.FromArgb(pColor.Red, pColor.Green, pColor.Blue);
                nudWidth.Value = Convert.ToDecimal(((ILineSymbol)pStyleGalleryItem.Item).Width);
            }

            if (((IFeatureLayer)pLayer).FeatureClass.ShapeType == esriGeometryType.esriGeometryPolygon)
            {
                IRgbColor pColor = ((IFillSymbol)pStyleGalleryItem.Item).Color as IRgbColor;
                btColor.BackColor = Color.FromArgb(pColor.Red, pColor.Green, pColor.Blue);
                nudWidth.Value = Convert.ToDecimal(((IFillSymbol)pStyleGalleryItem.Item).Outline.Width);
                pColor = ((IFillSymbol)pStyleGalleryItem.Item).Outline.Color as IRgbColor;
                btOutlineColor.BackColor = Color.FromArgb(pColor.Red, pColor.Green, pColor.Blue);

                if (btColor.BackColor.Name == "ffffffff")
                {
                    btColor.Enabled = false;
                    cbColor.Enabled = false;
                }
                else
                {
                    btColor.Enabled = true;
                    cbColor.Enabled = true;
                }
            }
            
        }


        private void comboBox2_MouseClick(object sender, MouseEventArgs e)
        {
            button1_Click(btColor, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IRgbColor pColor = new RgbColor();
            pColor.RGB = 255;
            tagRECT pTag = new tagRECT();
            pTag.left = btColor.PointToScreen(System.Drawing.Point.Empty).X;
            pTag.bottom = btColor.PointToScreen(System.Drawing.Point.Empty).Y + btColor.Height;
            //pTag.left = SystemInformation.FrameBorderSize.Width + this.Left + groupBox2.Left + button1.Left;
            //pTag.bottom = (this.Height - this.ClientRectangle.Height - SystemInformation.FrameBorderSize.Height) + this.Top + groupBox2.Top + button1.Top + button1.Height;
            IColorPalette pColorPalette = new ColorPalette();
            pColorPalette.TrackPopupMenu(ref pTag, pColor, false, 0);
            pColor = pColorPalette.Color as IRgbColor;
            Color color = Color.FromArgb(pColor.Red, pColor.Green, pColor.Blue);
            btColor.BackColor = color;
            
            switch (((IFeatureLayer)pLayer).FeatureClass.ShapeType)
            {
                case esriGeometryType.esriGeometryPoint:
                    ((IMarkerSymbol)pStyleGalleryItem.Item).Color = pColor;
                    PreviewPicture();
            	    break;
                case esriGeometryType.esriGeometryPolyline:
                    ((ILineSymbol)pStyleGalleryItem.Item).Color = pColor;
                    PreviewPicture();
                    break;
                case esriGeometryType.esriGeometryPolygon:
                    ((IFillSymbol)pStyleGalleryItem.Item).Color = pColor;
                    PreviewPicture();
                    break;
                default:
                    break;
            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            switch (((IFeatureLayer)pLayer).FeatureClass.ShapeType)
            {
                case esriGeometryType.esriGeometryPoint:
                    ((IMarkerSymbol)pStyleGalleryItem.Item).Size = Convert.ToDouble(nudWidth.Value);
                    PreviewPicture();
            	    break;
                case esriGeometryType.esriGeometryPolyline:
                    ((ILineSymbol)pStyleGalleryItem.Item).Width = Convert.ToDouble(nudWidth.Value);
                    PreviewPicture();
                    break;
                case esriGeometryType.esriGeometryPolygon:
                    ILineSymbol pLineSymbol = ((IFillSymbol)pStyleGalleryItem.Item).Outline;
                    pLineSymbol.Width = Convert.ToDouble(nudWidth.Value);
                    ((IFillSymbol)pStyleGalleryItem.Item).Outline = pLineSymbol;
                    PreviewPicture();
                    break;
                default:
                    break;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            IRgbColor pColor = new RgbColor();
            pColor.RGB = 255;
            tagRECT ptagRECT = new tagRECT();
            ptagRECT.left = btOutlineColor.PointToScreen(System.Drawing.Point.Empty).X;
            ptagRECT.bottom = btOutlineColor.PointToScreen(System.Drawing.Point.Empty).Y + btOutlineColor.Height;
            IColorPalette pColorPalette = new ColorPalette();
            pColorPalette.TrackPopupMenu(ref ptagRECT, pColor, false, 0);
            pColor = pColorPalette.Color as IRgbColor;
            btOutlineColor.BackColor = Color.FromArgb(pColor.Red, pColor.Green, pColor.Blue);
            ILineSymbol pLineSymbol = ((IFillSymbol)pStyleGalleryItem.Item).Outline;
            pLineSymbol.Color = pColor;
            ((IFillSymbol)pStyleGalleryItem.Item).Outline = pLineSymbol;
            PreviewPicture();
        }

        private void comboBox3_MouseClick(object sender, MouseEventArgs e)
        {
            btOutlineColor.PerformClick();
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            ((IMarkerSymbol)pStyleGalleryItem.Item).Angle = Convert.ToDouble(nudAngle.Value);
            PreviewPicture();
        }

        private void btMore_Click(object sender, EventArgs e)
        {
            if (contextMenuMoreSymbolInitiated == false)
            {
                
                string stylePath = @"C:\Program Files (x86)\ArcGIS\Styles";
                string[] strFiles = Directory.GetFiles(stylePath, "*.ServerStyle");
                ToolStripMenuItem[] symbolContextMenuItem = new ToolStripMenuItem[strFiles.Length + 1];
                for (int i = 0; i < strFiles.Length; i++)
                {
                    symbolContextMenuItem[i] = new ToolStripMenuItem();
                    symbolContextMenuItem[i].CheckOnClick = true;
                    symbolContextMenuItem[i].Text = System.IO.Path.GetFileNameWithoutExtension(strFiles[i]);
                    if (symbolContextMenuItem[i].Text == "ESRI")
                    {
                        symbolContextMenuItem[i].Checked = true;
                    }
                    symbolContextMenuItem[i].Name = strFiles[i];
                }
                symbolContextMenuItem[strFiles.Length] = new ToolStripMenuItem();
                symbolContextMenuItem[strFiles.Length].Text = "更多工具";
                symbolContextMenuItem[strFiles.Length].Name = "AddMoreSymbol";
                contextMenuStrip1.Items.AddRange(symbolContextMenuItem);
                contextMenuMoreSymbolInitiated = true;
            }
                
            contextMenuStrip1.Show(btMore.Location);
        }

        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            ToolStripMenuItem pToolStripMenuItem = e.ClickedItem as ToolStripMenuItem;
            if (pToolStripMenuItem.Name == "AddMoreSymbol")
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    axSymbologyControl1.LoadStyleFile(openFileDialog1.FileName);
                    axSymbologyControl1.Refresh();
                }
            }
            else
            {
                if (pToolStripMenuItem.Checked == false)
                {
                    axSymbologyControl1.LoadStyleFile(pToolStripMenuItem.Name);
                    axSymbologyControl1.Refresh();
                }
                else
                {
                    axSymbologyControl1.RemoveFile(pToolStripMenuItem.Name);
                    axSymbologyControl1.Refresh();
                }
            }
        }
     
    }
}
